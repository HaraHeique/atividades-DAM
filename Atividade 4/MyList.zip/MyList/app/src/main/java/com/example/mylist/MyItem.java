package com.example.mylist;

import android.net.Uri;

public class MyItem {
    public Uri photo;
    public String title;
    public String description;
}
